=============================================================
ELITE COLLEGE - SIMPLE ANDROID APP
=============================================================

YE BILKUL SIMPLE APP HAI - SIRF 4 FILES!

ANDROID STUDIO MEIN KAISE OPEN KAREIN:
1. Android Studio open karein
2. File > Open > is folder ko select karein
3. Wait for Gradle sync
4. Run button dabayein

YA PHIR COMMAND LINE SE:
1. ./gradlew assembleDebug
2. APK folder: app/build/outputs/apk/debug/

YE APP SIRF KARTA HAI:
- WebView open karta hai
- elite-college.html load karta hai
- Bas! Koi extra feature nahi

NOTE:
- Agar HTML update karna ho to:
  app/src/main/assets/elite-college.html replace karein
=============================================================
